#include "ti_msp_dl_config.h"

void Servo_SetUpAngle(float Angle)
{
	DL_TimerA_setCaptureCompareValue(servo_INST,Angle/180*2000+500,GPIO_servo_C0_PIN);
}

void Servo_SetDownAngle(float Angle)
{
	DL_TimerA_setCaptureCompareValue(servo_INST,Angle/270*2000+500,GPIO_servo_C0_PIN);
}

